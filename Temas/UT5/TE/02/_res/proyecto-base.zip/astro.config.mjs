// @ts-check
import { defineConfig } from 'astro/config';
import siteData from './src/assets/data/site.json';
import tailwindcss from '@tailwindcss/vite';

// https://astro.build/config
export default defineConfig({
  site: siteData.site,  //Asigna información sobre el sitio
  vite: {
    plugins: [tailwindcss()]
  }
});