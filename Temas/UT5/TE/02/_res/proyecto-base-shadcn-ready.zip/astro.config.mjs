// @ts-check
import { defineConfig } from 'astro/config';
import siteData from './src/assets/data/site.json';
import tailwindcss from '@tailwindcss/vite';

import react from '@astrojs/react';

// https://astro.build/config
export default defineConfig({
  //Asigna información sobre el sitio
  site: siteData.site,

  vite: {
    plugins: [tailwindcss()]
  },

  integrations: [react()]
});