
/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      fontFamily: {
        tomaso: ['Tomaso', 'sans-serif'],
        jura: ['Jura', 'sans-serif'],
      },
      colors: {
        primary: 'rgb(253 224 71);',
      },
    },
  }
}